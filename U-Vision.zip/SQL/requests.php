<?php
const SQL_SELECT_ALL_FILMS_RU = "SELECT * FROM filmsRU;";
const SQL_SELECT_ALL_FILMS_UA = "SELECT * FROM filmsUA;";
 ?>
